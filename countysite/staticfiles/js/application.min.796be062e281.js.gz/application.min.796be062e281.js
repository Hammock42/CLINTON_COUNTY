function mapReady() {
  document.dispatchEvent(new CustomEvent("map-derp", null));
}
function infoboxReady() {
  document.dispatchEvent(new CustomEvent("infobox-derp", null));
}
function clusterReady() {
  document.dispatchEvent(new CustomEvent("cluster-derp", null));
}
function my_checker(eventName) {
  return function () {
    return new Promise(function (resolve, reject) {
      var x = setTimeout(function () {
          document.removeEventListener(eventName, resolver), reject();
        }, 1e4),
        resolver = function () {
          clearTimeout(x),
            document.removeEventListener(eventName, resolver),
            resolve();
        };
      document.addEventListener(eventName, resolver);
    });
  };
}
var mapIsReady = my_checker("map-derp"),
  infoboxIsReady = my_checker("infobox-derp"),
  clusterIsReady = my_checker("cluster-derp");
(window.mapsReady = Promise.all([
  mapIsReady(),
  infoboxIsReady(),
  clusterIsReady(),
])),
  (function (factory) {
    "function" == typeof define && define.amd
      ? define(["jquery"], factory)
      : "object" == typeof exports
      ? factory(require("jquery"))
      : factory(jQuery);
  })(function ($) {
    var pluses = /\+/g;
    function encode(s) {
      return config.raw ? s : encodeURIComponent(s);
    }
    function read(value, converter) {
      value = config.raw
        ? value
        : (function (s) {
            0 === s.indexOf('"') &&
              (s = s.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\"));
            try {
              return (
                (s = decodeURIComponent(s.replace(pluses, " "))),
                config.json ? JSON.parse(s) : s
              );
            } catch (e) {}
          })(value);
      return $.isFunction(converter) ? converter(value) : value;
    }
    var config = ($.cookie = function (key, value, options) {
      if (void 0 !== value && !$.isFunction(value)) {
        var t, expirationInMins, expire_date;
        (function (cname) {
          for (
            var name = cname + "=", ca = document.cookie.split(";"), i = 0;
            i < ca.length;
            i++
          ) {
            for (var c = ca[i]; " " == c.charAt(0); ) c = c.substring(1);
            if (0 == c.indexOf(name)) return c.substring(name.length, c.length);
          }
        })("CookieConsent");
        return (
          "number" ==
          typeof (options = $.extend({}, config.defaults, options)).expires
            ? ((expirationInMins = options.expires),
              (t = options.expires = new Date()).setTime(
                +t + 864e5 * expirationInMins
              ))
            : ((expirationInMins = expire_date = expire_date || 10),
              "pressUid" === key &&
                (expirationInMins = cookieExpireMinPressroom),
              (expire_date = options.expires = new Date()).setTime(
                expire_date.getTime() + 60 * expirationInMins * 1e3
              )),
          (document.cookie = [
            encode(key),
            "=",
            (function (value) {
              return encode(
                config.json ? JSON.stringify(value) : String(value)
              );
            })(value),
            options.expires ? "; expires=" + options.expires.toUTCString() : "",
            options.path ? "; path=" + options.path : "",
            options.domain ? "; domain=" + options.domain : "",
            options.secure ? "; secure" : "",
          ].join(""))
        );
      }
      for (
        var result = key ? void 0 : {},
          cookies = document.cookie ? document.cookie.split("; ") : [],
          i = 0,
          l = cookies.length;
        i < l;
        i++
      ) {
        var cookie = cookies[i].split("="),
          name =
            ((name = cookie.shift()),
            config.raw ? name : decodeURIComponent(name)),
          cookie = cookie.join("=");
        if (key && key === name) {
          result = read(cookie, value);
          break;
        }
        key || void 0 === (cookie = read(cookie)) || (result[name] = cookie);
      }
      return result;
    });
    (config.defaults = {}),
      ($.removeCookie = function (key, options) {
        return (
          void 0 !== $.cookie(key) &&
          ($.cookie(key, "", $.extend({}, options, { expires: -1 })),
          !$.cookie(key))
        );
      });
  });
var alertsComponent = void $(function () {
    var container = $("div.alert-container");
    0 < container.length &&
      $("button.alert-close", container).on("click", function () {
        container.remove(),
          $("body").removeClass("has-alerts"),
          $.cookie("displayAlert", !1, { path: "/", expires: 1 / 6 });
      });
  }),
  announcementComponent = void $(function () {
    var container = $("div.announcement-container");
    0 < container.length &&
      ((my_modal = $("#announcementModal")),
      my_modal.modal({ backdrop: "static", keyboard: !1, show: !0 }),
      $("button.announcement-close").on("click", function () {
        container.remove(),
          $("body").removeClass("has-announcement"),
          $.cookie("displayAnnouncement", !1, { path: "/" }),
          my_modal.modal("hide");
      }),
      $(".announcement-action").on("click", function () {
        container.remove(),
          $("body").removeClass("has-announcement"),
          $.cookie("displayAnnouncement", !1, { path: "/" }),
          my_modal.modal("hide");
      }));
  });
function addPagePathToCMSChannelManager() {
  var newNode,
    toolbarLeftBlock = parent.parent.window.frames[0].document.querySelector(
      ".md-toolbar-tools .layout-align-start-center"
    );
  toolbarLeftBlock &&
    ("" == hstRequestPathInfo &&
      "undefined" !== hstSiteMapItemId &&
      "root" == hstSiteMapItemId &&
      (hstRequestPathInfo = "root"),
    (newNode = toolbarLeftBlock.querySelector("span.current-path"))
      ? (newNode.innerHTML = hstRequestPathInfo)
      : (((newNode = document.createElement("div")).innerHTML =
          "<span class='current-path' style='white-space:nowrap;padding:0 20px 0px 20px;font-weight:bold;'>" +
          hstRequestPathInfo +
          "</span>"),
        toolbarLeftBlock.appendChild(newNode)));
}
function moveViewPortNodeToRightSide() {
  var rightBlock,
    viewportNode = parent.parent.window.frames[0].document.querySelector(
      ".md-toolbar-tools .layout-align-center-center viewport-toggle"
    );
  viewportNode &&
    (rightBlock = parent.parent.window.frames[0].document.querySelector(
      ".md-toolbar-tools .layout-align-end-center"
    )).insertBefore(viewportNode, rightBlock.firstChild);
}
window.mapsReady
  .then(function () {
    $(".build-your-own-adventure-results").each(function (
      index,
      mapLoadButton
    ) {
      var map,
        attractions,
        markers,
        markerCluster,
        icon,
        mapOptions,
        infoBox,
        mapComponent = $(mapLoadButton),
        mapCanvas = mapComponent.find(".map-canvas");
      function initializeMap() {
        map = new google.maps.Map(mapCanvas[0], mapOptions);
        var listingsObject = mapComponent.data("allListings");
        listingsObject
          ? (attractions = listingsObject)
          : ((listingsObject = mapComponent
              .find(".byoa-map-results-chunk")
              .data("listings")),
            (attractions = listingsObject),
            mapComponent[0].addEventListener(
              "loadedMoreByoaResults",
              function (listingsObject) {
                listingsObject = listingsObject.detail;
                attractions.push(...listingsObject), updateMap();
              }
            )),
          google.maps.event.addListenerOnce(map, "tilesloaded", function () {
            document.getElementsByTagName("iframe")[0].title = "Google Maps";
          }),
          updateMap();
      }
      function updateMap() {
        var markerPositionCounts;
        map.panBy(0, 0),
          (markers = []),
          attractions.forEach(function (attraction, i) {
            var marker = new google.maps.LatLng(
                attraction.latitude,
                attraction.longitude
              ),
              marker = new google.maps.Marker({
                position: marker,
                map: map,
                draggable: !1,
                icon: icon,
                label: { text: String(1), color: "black" },
              });
            markers.push(marker),
              attraction.scrollCopyTo
                ? google.maps.event.addListener(marker, "click", function () {
                    selectMapMarkerForItem(i),
                      scrollToCopySection(attraction.scrollCopyTo);
                  })
                : google.maps.event.addListener(marker, "click", function () {
                    selectMapMarkerForItem(i);
                  });
          }),
          (function () {
            var bounds = new google.maps.LatLngBounds(),
              markerCount = 0;
            markers.forEach(function (marker) {
              var lat = marker.getPosition().lat(),
                lng = marker.getPosition().lng();
              lat == lat &&
                0 != lat &&
                lng == lng &&
                0 != lng &&
                marker.getVisible() &&
                (markerCount++, bounds.extend(marker.getPosition()));
            }),
              bounds.isEmpty() &&
                (bounds.extend(new google.maps.LatLng(49, -104.0487)),
                bounds.extend(new google.maps.LatLng(44.37, -116)));
            1 === markerCount &&
              google.maps.event.addListenerOnce(
                map,
                "bounds_changed",
                function () {
                  this.setZoom(14);
                }
              );
            map.fitBounds(bounds);
          })(),
          initializeCluster(),
          (markerPositionCounts = []),
          markers.forEach(function (marker) {
            var matchingCount = markerPositionCounts.find(function (
              markerPositionCount
            ) {
              return (
                markerPositionCount.position.lat == marker.position.lat() &&
                markerPositionCount.position.lng == marker.position.lng()
              );
            });
            matchingCount
              ? (offsetMarker(marker, 15e-6 * matchingCount.count),
                matchingCount.count++)
              : markerPositionCounts.push({
                  position: marker.position,
                  count: 1,
                });
          });
      }
      function initializeCluster() {
        markerCluster && markerCluster.clearMarkers();
        (markerCluster = new MarkerClusterer(map, markers, {
          styles: [
            {
              textColor: "black",
              width: 40,
              height: 64,
              url: "/binaries/content/gallery/MTOT/icons/mappin.svg",
              anchor: [10, 0],
            },
          ],
          maxZoom: 22,
        })),
          google.maps.event.addListener(
            markerCluster,
            "clusterclick",
            function (cluster) {}
          );
      }
      function selectMapMarkerForItem(i) {
        markers.forEach(function (marker) {
          marker.setZIndex();
        }),
          markers[i].setZIndex(google.maps.Marker.MAX_ZINDEX + 1),
          infoBox.close();
        var attraction = attractions[i],
          svgPath = "";
        attraction.url &&
          (svgPath =
            '<a class="visitmt-button attraction-button" href="' +
            attraction.url +
            '">See More...<svg class="arrow" viewBox="-400 0 500 100" preserveAspectRatio="xMaxYMid slice" > <rect x="-400" y="45" width="490" height="10" style="fill:currentColor" /> <polygon points="100,50 22,0 22,15 80,50 22,85 22,100" style="fill:currentColor" /></svg></a>');
        svgPath =
          '<div class="infobox"><svg class="map-icon" style="width:39px;height:53px;top: -23.5px;position: absolute;left: 38.5px; transform:translateX(-50%);" viewBox="0 0 39 53" preserveAspectRatio="xMaxYMid slice"><path fill="white" stroke="#4f5a3b" d="M 20 53 L 39 23 L  1 23 L 20 53"/><path stroke="white" stroke-width="2px" d="M 35 23 L  5 23"/></svg><div class="infobox-body"><h5 class="attraction-title">' +
          attraction.title +
          '</h5><h5 class="attraction-type">' +
          attraction.siteType +
          '</h5><picture><source media="(max-width: 767px)" srcset="' +
          attraction.imageMobile +
          '"><img src="' +
          attraction.imageDesktop +
          '" class="attraction-image" alt="' +
          attraction.imageAltText +
          '" aria-label="${document.image.imageAltText!}"></picture><h5 class="attraction-city">' +
          attraction.city +
          "</h5>" +
          svgPath +
          "</div></div>";
        infoBox.setContent(svgPath), infoBox.open(map, markers[i]);
      }
      0 != mapCanvas.length &&
        ((attractions = []),
        (markers = []),
        (icon = {
          path: "M 20 53, L 39 23, L 35 23, A 16 16 0 1 0 5 23, L  1 23, L 20 53",
          anchor: new google.maps.Point(20, 53),
          strokeWeight: 1,
          strokeColor: "#4f5a3b",
          fillColor: "#FFFFFF",
          fillOpacity: 1,
          scale: 1,
          labelOrigin: new google.maps.Point(20, 17),
        }),
        (mapOptions = {
          mapTypeId: google.maps.MapTypeId.ROADMAP,
          scrollwheel: !1,
          styles: [
            {
              featureType: "administrative.province",
              elementType: "geometry.stroke",
              stylers: [{ weight: "4" }],
            },
            {
              featureType: "administrative",
              elementType: "labels.text.fill",
              stylers: [{ color: "#000000" }],
            },
          ],
        }),
        (mapLoadButton = new google.maps.LatLng(44.428, -110.5885)),
        new google.maps.Marker({
          position: mapLoadButton,
          map: map,
          draggable: !1,
          icon: { path: google.maps.SymbolPath.CIRCLE, scale: 0 },
          label: {
            text: "Yellowstone National Park",
            color: "black",
            fontSize: "14px",
            fontWeight: "Bold",
          },
        }),
        (mapLoadButton = new google.maps.LatLng(48.7596, -113.787)),
        new google.maps.Marker({
          position: mapLoadButton,
          map: map,
          draggable: !1,
          icon: { path: google.maps.SymbolPath.CIRCLE, scale: 0 },
          label: {
            text: "Glacier National Park",
            color: "black",
            fontSize: "14px",
            fontWeight: "Bold",
          },
        }),
        (infoBox = new InfoBox({
          pixelOffset: new google.maps.Size(-40, -31),
          maxWidth: 275,
          disableAutoPan: !1,
          zIndex: 10,
          boxClass: "visitmt-map-infobox",
          boxStyle: { background: "white" },
          closeBoxMargin: "0",
          closeBoxURL:
            $("body").data("context-path") +
            "/binaries/content/gallery/MTOT/icons/modal-close-button.png",
          infoBoxClearance: new google.maps.Size(1, 1),
          isHidden: !1,
          pane: "floatPane",
          enableEventPropagation: !1,
          alignBottom: !1,
        })),
        $("[data-select-visitmt-map-marker]").click(function () {
          selectMapMarkerForItem($(this).data("select-visitmt-map-marker"));
        }),
        $("[data-show-visitmt-map-marker]").click(function () {
          infoBox.close();
          var markersToShow = $(this).data("show-visitmt-map-marker");
          markers.forEach(function (marker) {
            marker.setVisible(!1);
          }),
            markersToShow.forEach(function (i) {
              markers[i].setVisible(!0);
            }),
            initializeCluster();
        }),
        $("[data-set-map-header-text]").click(function () {
          mapComponent
            .find(".map-title")
            .text($(this).data("set-map-header-text"));
        }),
        0 == (mapLoadButton = mapComponent.find(".map-load-button")).length
          ? initializeMap()
          : mapLoadButton.click(initializeMap));
    }),
      $("#main-content").click(function (url) {
        var resultsContainer,
          resultsChunk =
            ".build-your-own-adventure-results .byoa-map-results-chunk .load-more-button";
        (url.target.matches(resultsChunk) ||
          url.target.matches(resultsChunk + " *")) &&
          ((resultsChunk = (url = url.target.closest(resultsChunk)).closest(
            ".byoa-map-results-chunk"
          )),
          (resultsContainer = resultsChunk.closest(
            ".build-your-own-adventure-results"
          )),
          (url = $(url).data("url")),
          $(resultsChunk).remove(),
          $.get(url, function (data) {
            $(resultsContainer).append(data),
              resultsContainer.dispatchEvent(
                new CustomEvent("loadedMoreByoaResults", {
                  detail: $(data).data("listings"),
                  bubbles: !0,
                })
              );
          }));
      });
  })
  .catch(function () {
    console.log("maps libraries failed to load!");
  }),
  $(function () {
    "undefined" != typeof cmsRequest &&
      cmsRequest &&
      "undefined" != typeof hstRequestPathInfo &&
      (parent.parent.window.frames[0].document.querySelector(".hippo-toolbar"),
      addPagePathToCMSChannelManager(),
      moveViewPortNodeToRightSide());
  }),
  $(function () {
    (eventDetailComponent = $(".event-detail-component")),
      (eventDetailTabSelection = $(".detail-tab-button")),
      (dropdownArrow = $(".event-detail-component .dropdown-arrow")),
      (eventDetailTabs = $(".detail-tab")),
      $(eventDetailTabSelection).each(function (index, element) {
        $(element).click(function (e) {
          var selectedTab = $(element).data("tab");
          $(eventDetailTabs).each(function (index, tab) {
            $(tab).removeClass("active");
          }),
            $(eventDetailTabSelection).each(function (index, tab) {
              $(tab).removeClass("active");
            }),
            $(element).addClass("active"),
            $(".detail-tab-button." + selectedTab).addClass("active"),
            $(".detail-tab." + selectedTab).addClass("active"),
            $(".event-detail-tab-dropdown").addClass("hide");
        });
      }),
      $(dropdownArrow).click(function (e) {
        $(".event-detail-tab-dropdown").toggleClass("hide");
      });
  }),
  (function () {
    var dropdownOptionsContainer = $("#CityOptions"),
      options = dropdownOptionsContainer.children(),
      cityInput = $("#CityInput");
    function displayAllDropdownOptions() {
      dropdownOptionsContainer.removeClass("hide"),
        $(options).each(function (index, element) {
          $(element).removeClass("hide");
        });
    }
    $(".event-search-section").each(function (index, element) {
      $("#CityInput").on("input", function (cityInputEvent) {
        !(function (inputText) {
          0 == inputText.length
            ? displayAllDropdownOptions()
            : (dropdownOptionsContainer.removeClass("hide"),
              $(options).each(function (index, element) {
                element.innerHTML
                  .toLowerCase()
                  .startsWith(inputText.toLowerCase())
                  ? $(element).removeClass("hide")
                  : $(element).addClass("hide");
              }));
        })(cityInputEvent.target.value);
      }),
        $("#CityInput, #CityOptions, .city-selection, .city-option").focus(
          function (e) {
            displayAllDropdownOptions();
          }
        ),
        $("#CityInput, #CityOptions, .city-selection, .city-option").blur(
          function (e) {
            $(options).each(function (index, selectedCity) {
              selectedCity.matches(":hover") &&
                ((selectedCity = selectedCity.innerHTML),
                $(cityInput).val(selectedCity));
            }),
              dropdownOptionsContainer.addClass("hide");
          }
        );
    });
  })(),
  (function () {
    var carousel = $(".event-spotlight-section .owl-carousel");
    0 < carousel.length &&
      carousel.owlCarousel({
        loop: !1,
        nav: !0,
        navContainerClass: "carousel-nav-container",
        navClass: ["carousel-previous-button", "carousel-next-button"],
        navText: [
          '<svg class="arrow" viewBox="0 0 34 34"><polygon points="20,11 20,10 10,16 10,17 20,23 20,22 11,16.5" style="fill:currentColor"></polygon></svg>',
          '<svg class="arrow" viewBox="0 0 34 34"><polygon points="13,11 13,10 23,16 23,17 13,23 13,22 22,16.5" style="fill:currentColor"></polygon></svg>',
        ],
        mouseDrag: !1,
        touchDrag: !1,
        pullDrag: !1,
        dots: !1,
        freeDrag: !1,
        autoWidth: !0,
      });
  })(),
  $(".visitmt-fancy-dropdown-container").each(function (index, container) {
    $(container).focus(function (e) {
      $(container).find(".visitmt-fancy-dropdown-options").removeClass("hide");
    }),
      $(container).blur(function (e) {
        $(container).find(".visitmt-fancy-dropdown-options").addClass("hide");
      });
    var dropdownOptions = $(container).find(".visitmt-fancy-dropdown-option");
    $(dropdownOptions).click(function (value) {
      var label = value.target,
        value = $(label).data("value"),
        label = $(label).data("label");
      $(container).find("input").val(value),
        $(container).find(".visitmt-fancy-dropdown-field").text(label),
        $(container).blur();
    });
  }),
  $(".mad-lib-input").each(function (index, element) {
    $(element).data("selected", "set");
  });
var featuredContent2X2Component = {};
null !== document.getElementById("feature-content-2x2-section") &&
  (featuredContent2x2Component = (function () {
    function deviceCode() {
      var screenCode = 1,
        w =
          window.innerWidth ||
          document.documentElement.clientWidth ||
          document.body.clientWidth;
      return (
        /ipad|tablet/i.test(navigator.userAgent) && 768 <= w && w < 996
          ? (screenCode = 2)
          : /mobile/i.test(navigator.userAgent) && w < 768 && (screenCode = 3),
        screenCode
      );
    }
    var groupCount = $(".featured-content-2x2-container").data("group-count");
    function setupDisplay() {
      var fc2x2, items;
      1 < deviceCode()
        ? ((itemCount = 2 * groupCount),
          (items = $(".fc-2x2-item-container-mobile")) &&
            0 < items.length &&
            $(".fc-2x2-item-container-mobile").each(function (i, obj) {
              $(this).show();
            }))
        : ((-1 == navigator.userAgent.indexOf("MSIE") &&
            -1 == navigator.userAgent.indexOf("Trident/7.0")) ||
            ((fc2x2 = $(".fc-2x2-item-button")) &&
              fc2x2.css("margin-top", "380px")),
          (items = $(".featured-content-2x2-row")) &&
            0 < items.length &&
            $(".featured-content-2x2-row").each(function (i, obj) {
              $(this).show();
            }));
    }
    function resetDisplay() {
      $(".featured-content-2x2-wrapper").hide(),
        $(".featured-content-2x2-wrapper-mobile").hide(),
        (1 < deviceCode()
          ? $(".featured-content-2x2-wrapper-mobile")
          : $(".featured-content-2x2-wrapper")
        ).show();
    }
    resetDisplay(),
      setupDisplay(),
      $(".fc-2x2-item-map-canvas").on({
        mouseenter: function (e) {
          var $itemDiv = $(this).parent().find(".fc-2x2-item");
          $itemDiv && $itemDiv.hide(), e.preventDefault();
        },
        mouseleave: function (e) {
          var $itemDiv = $(this).parent().find(".fc-2x2-item");
          $itemDiv && $itemDiv.show(), e.preventDefault();
        },
      }),
      $(".fc-2x2-item-map-canvas-mobile").click(function (e) {
        $(this).parent().parent().find(".fc-2x2-item-mobile").hide();
      }),
      $(".fc-2x2-item-map-canvas-mobile-container-exit-button").click(function (
        e
      ) {
        $(this).parent().parent().find(".fc-2x2-item-mobile").show();
      }),
      $(window).resize(function () {
        resetDisplay(), setupDisplay();
      });
  })());
var featuredContent3X3Component = {};
null !== document.getElementById("feature-content-3x3-section") &&
  (featuredContent3x3Component = (function () {
    function deviceCode() {
      var screenCode = 1,
        w =
          window.innerWidth ||
          document.documentElement.clientWidth ||
          document.body.clientWidth;
      return (
        /ipad|tablet/i.test(navigator.userAgent) && 768 <= w && w < 992
          ? (screenCode = 2)
          : /mobile/i.test(navigator.userAgent) && w < 768 && (screenCode = 3),
        screenCode
      );
    }
    var groupCount = $(".featured-content-3x3-container").data("group-count"),
      visibleRowCount = 3,
      visibleMobileItemCount = 3;
    function resetMobileItemDisplay() {
      var items;
      1 < deviceCode() &&
        ((itemCount = 3 * groupCount),
        (items = $(".fc-3x3-item-container-mobile")) &&
          0 < items.length &&
          $(".fc-3x3-item-container-mobile").each(function ($itemDiv, obj) {
            $itemDiv < visibleMobileItemCount &&
              ($itemDiv = $(this).find(".fc-3x3-item-mobile")) &&
              $itemDiv.show();
          }));
    }
    function setupDisplay() {
      var fc3x3, items;
      1 < deviceCode()
        ? ((itemCount = 3 * groupCount),
          visibleMobileItemCount == itemCount && $(".load-more-button").hide(),
          (items = $(".fc-3x3-item-container-mobile")) &&
            0 < items.length &&
            $(".fc-3x3-item-container-mobile").each(function (i, obj) {
              i < visibleMobileItemCount ? $(this).show() : $(this).hide();
            }))
        : ((-1 == navigator.userAgent.indexOf("MSIE") &&
            -1 == navigator.userAgent.indexOf("Trident/7.0")) ||
            ((fc3x3 = $(".fc-3x3-item-button")) &&
              fc3x3.css("margin-top", "380px")),
          (visibleRowCount == groupCount || groupCount < 3) &&
            $(".load-more-button").hide(),
          (items = $(".featured-content-3x3-row")) &&
            0 < items.length &&
            $(".featured-content-3x3-row").each(function (i, obj) {
              i < visibleRowCount ? $(this).show() : $(this).hide();
            }));
    }
    function resetDisplay() {
      $(".featured-content-3x3-wrapper").hide(),
        $(".featured-content-3x3-wrapper-mobile").hide(),
        (1 < deviceCode()
          ? $(".featured-content-3x3-wrapper-mobile")
          : $(".featured-content-3x3-wrapper")
        ).show();
    }
    resetDisplay(),
      setupDisplay(),
      $(".load-more-button").click(function (e) {
        (itemCount = 3 * groupCount),
          1 < deviceCode() && visibleMobileItemCount < itemCount
            ? visibleMobileItemCount++
            : visibleRowCount < groupCount && visibleRowCount++,
          setupDisplay(),
          e.preventDefault();
      }),
      $(".fc-3x3-item-map-canvas").on({
        mouseenter: function (e) {
          var $itemDiv = $(this).parent().find(".fc-3x3-item");
          $itemDiv && $itemDiv.hide(), e.preventDefault();
        },
        mouseleave: function (e) {
          var $itemDiv = $(this).parent().find(".fc-3x3-item");
          $itemDiv && $itemDiv.show(), e.preventDefault();
        },
      }),
      $(".fc-3x3-item-map-canvas-mobile").click(function (e) {
        resetMobileItemDisplay();
        var $itemDiv = $(this).parent().find(".fc-3x3-item-mobile");
        $itemDiv && $itemDiv.hide(), e.preventDefault();
      }),
      $(window).scroll(function (e) {
        resetMobileItemDisplay(), e.preventDefault();
      }),
      $(window).resize(function () {
        resetDisplay(), setupDisplay();
      });
  })()),
  $(function () {
    $(".visitmt-form").each(function (_, element) {
      var formElement = $(element),
        submissionPath = formElement.data("submissionPath"),
        confirmPagePath = formElement.data("confirmPagePath");
      formElement.submit(function (a) {
        var o;
        a.preventDefault(),
          "" == $("#g-recaptcha-response").val()
            ? ($("div.captcha").addClass("has-error"),
              $("small.help-block", "div.captcha")
                .removeClass("hidden")
                .html("This field is required"),
              $(".g-recaptcha iframe").css("border", "2px solid #F00"))
            : $.ajax({
                url: submissionPath,
                contentType: "application/json",
                data: JSON.stringify(
                  ((a = formElement),
                  (o = {}),
                  (a = $(formElement).serializeArray()),
                  $.each(a, function () {
                    o[this.name]
                      ? (o[this.name].push || (o[this.name] = [o[this.name]]),
                        o[this.name].push(this.value || ""))
                      : (o[this.name] = this.value || "");
                  }),
                  o)
                ),
                type: "POST",
                success: function (p) {
                  "200" == p.status
                    ? (window.location = confirmPagePath)
                    : "201" == p.status
                    ? ($("div.captcha").addClass("has-error"),
                      $("small.help-block", "div.captcha")
                        .removeClass("hidden")
                        .html(p.message),
                      $(".g-recaptcha iframe").css("border", "2px solid #F00"))
                    : ((p = $(document.createElement("p"))
                        .addClass("help-block")
                        .html(p.message)),
                      $("div.errors")
                        .addClass("has-error")
                        .html(p)
                        .removeClass("hidden"));
                },
                error: function (resp) {
                  console.error(resp);
                },
              });
      }),
        element
          .querySelectorAll(".checkbox-conditional-field")
          .forEach((checkboxConditionalField) => {
            function checkField() {
              triggeringField.checked == triggeringValue
                ? (checkboxConditionalField.closest(".form-group").hidden = !1)
                : (checkboxConditionalField.closest(".form-group").hidden = !0);
            }
            var triggeringField = element.querySelector(
                "#" + checkboxConditionalField.dataset.triggeringField
              ),
              triggeringValue =
                (triggeringValue =
                  checkboxConditionalField.dataset.triggeringValue) || !0;
            checkField(),
              triggeringField.addEventListener("change", checkField);
          });
    }),
      setInterval(function () {
        var value = $(".g-recaptcha-response").val();
        void 0 !== value &&
          "" != value &&
          ($("div.captcha").removeClass("has-error"),
          $("small.help-block", "div.captcha").addClass("hidden").html(""),
          $(".g-recaptcha iframe").css("border", "none")),
          $("#g-recaptcha-response").attr(
            "title",
            "Hidden Recaptcha textfield"
          );
      }, 500),
      $("label").each(function () {
        0 <= $(this).html().indexOf("*") &&
          0 == $(this).find("span").size() &&
          $(this).prepend("<span class='sr-only'>Required Field </span>");
      });
  }),
  $(function () {
    $("#interestsSelection").toggle(),
      $("#interestsSelectionButton").click(function (e) {
        $("#interestsSelection").toggle();
      });
  }),
  ((myApp = myApp || {}).headerMenuDesktop = (function () {
    "use strict";
    var pub = {},
      nav = document.querySelector(".visitmt-nav"),
      menu = nav.querySelector(".menu.lvl1"),
      menuItemsLvl1 = nav.querySelectorAll(".menu-item.lvl1"),
      menuButtons = nav.querySelectorAll(
        ".menu-item.lvl1 button.menu-item-text"
      ),
      menuItemsAll = nav.querySelectorAll(".menu-item-text"),
      menuCloseButtons = nav.querySelectorAll(".menu-close"),
      activeMenuItem = null;
    (pub.init = function () {
      menu.addEventListener("keydown", processKeys),
        menuButtons.forEach(function (menuButton) {
          menuButton.addEventListener("click", toggleSubmenuItem),
            menuButton.addEventListener("blur", closeOnLeave);
        }),
        menuItemsAll.forEach(function (submenuItem) {
          submenuItem.addEventListener("blur", closeOnLeave);
        }),
        window.addEventListener("scroll", manageInitialPageScroll),
        document.addEventListener("click", closeMenusIfClickedOutside),
        menuCloseButtons.forEach(function (menuCloseButton) {
          menuCloseButton.addEventListener("click", closeAllMenus);
        });
    }),
      (pub.deinit = function () {
        menu.removeEventListener("keydown", processKeys),
          menuButtons.forEach(function (menuButton) {
            menuButton.removeEventListener("click", toggleSubmenuItem),
              menuButton.removeEventListener("blur", closeOnLeave);
          }),
          menuItemsAll.forEach(function (submenuItem) {
            submenuItem.removeEventListener("blur", closeOnLeave);
          }),
          window.removeEventListener("scroll", manageInitialPageScroll),
          document.removeEventListener("click", closeMenusIfClickedOutside),
          menuCloseButtons.forEach(function (menuCloseButton) {
            menuCloseButton.removeEventListener("click", closeAllMenus);
          });
      });
    var windowScrollCurrent = window.scrollY,
      windowScrollDifference = 0,
      scrollAmount = 25;
    function manageInitialPageScroll() {
      Math.abs(window.scrollY - windowScrollCurrent) > scrollAmount &&
        ((windowScrollDifference = window.scrollY - windowScrollCurrent),
        (windowScrollCurrent = window.scrollY)),
        100 <= window.scrollY
          ? 0 < windowScrollDifference && $("#siteHeader").addClass("scrolled")
          : windowScrollDifference < 0 &&
            $("#siteHeader").removeClass("scrolled");
    }
    function toggleSubmenuItem(event) {
      var menuItem = this.closest(".menu-item.lvl1");
      menuItem.classList.toggle("submenu-active"),
        menuItem.classList.contains("submenu-active") &&
          (activeMenuItem = menuItem),
        closeInactiveMenus(),
        myApp.headerMenu.loadOpenContent(menu);
    }
    function closeMenusIfClickedOutside(touchOrClickEvent) {
      null == touchOrClickEvent.target.closest(".menu-item.lvl1") &&
        closeAllMenus();
    }
    function closeOnLeave(blurEvent) {
      null === blurEvent.relatedTarget ||
        menu.contains(blurEvent.relatedTarget) ||
        closeAllMenus();
    }
    function closeAllMenus() {
      (activeMenuItem = null), closeInactiveMenus();
    }
    function closeInactiveMenus() {
      menuItemsLvl1.forEach(function (item) {
        item !== activeMenuItem && item.classList.remove("submenu-active");
      });
    }
    function processKeys(keydownEvent) {
      "Escape" === keydownEvent.key &&
        (activeMenuItem.contains(keydownEvent.target) &&
          !keydownEvent.target.matches("button.menu-item-text") &&
          activeMenuItem.querySelector("button.menu-item-text").focus(),
        closeAllMenus());
    }
    return pub;
  })()),
  ((myApp = myApp || {}).headerMenuMobile = (function () {
    "use strict";
    var pub = {},
      mobileNav = document.querySelector("#siteHeader .visitmt-nav"),
      mobileHeader = mobileNav.querySelector(".mobile-header"),
      mobileMenu = mobileNav.querySelector(".menu.lvl1"),
      menuButton = mobileNav.querySelector("button.hamburger"),
      openContentButtons = mobileNav.querySelectorAll(
        "button.main-menu-modal-open-button"
      ),
      closeContentButtons = mobileNav.querySelectorAll(
        "button.main-menu-modal-close-button"
      ),
      menuLvl1Items = mobileNav.querySelectorAll(".lvl1.menu-item"),
      menuLvl1ItemTexts = mobileNav.querySelectorAll(
        ".lvl1.menu-item .lvl1.menu-item-text"
      ),
      body = document.querySelector("body");
    document.querySelectorAll(
      ".visitmt-nav .menu-item.lvl1 span, .desktop-nav .menu-item.lvl1 a"
    );
    function menuButtonHandler(touchOrClickEvent) {
      (mobileMenu.style.top =
        mobileHeader.offsetTop + mobileHeader.offsetHeight + "px"),
        toggleMenuLvl1();
    }
    function lvl1handler(touchOrClickEvent) {
      "A" !== this.nodeName && openMenuLvl2(this.closest(".lvl1.menu-item"));
    }
    function showOpenContentHandler(touchOrClickEvent) {
      this.parentNode
        .querySelector(".main-menu-open-content-container")
        .classList.add("active");
    }
    function hideOpenContentHandler(touchOrClickEvent) {
      this.closest(".main-menu-open-content-container").classList.remove(
        "active"
      );
    }
    (pub.init = function () {
      menuButton.addEventListener("click", menuButtonHandler),
        (menuButton.style.touchAction = "manipulation"),
        menuLvl1ItemTexts.forEach(function (element) {
          (element.style.touchAction = "manipulation"),
            element.classList.add("my-class"),
            element.addEventListener("click", lvl1handler);
        }),
        document.addEventListener("focusin", closeMenuLvl1IfUnfocused),
        document.addEventListener("click", closeMenuLvl1IfTouchedOutside),
        openContentButtons.forEach(function (element) {
          (element.style.touchAction = "manipulation"),
            element.addEventListener("click", showOpenContentHandler);
        }),
        closeContentButtons.forEach(function (element) {
          (element.style.touchAction = "manipulation"),
            element.addEventListener("click", hideOpenContentHandler);
        });
    }),
      (pub.deinit = function () {
        closeMenuLvl1(),
          menuButton.removeEventListener("click", menuButtonHandler),
          menuLvl1ItemTexts.forEach(function (element) {
            element.removeEventListener("click", lvl1handler);
          }),
          document.removeEventListener("focusin", closeMenuLvl1IfUnfocused),
          document.removeEventListener("click", closeMenuLvl1IfTouchedOutside),
          openContentButtons.forEach(function (element) {
            element.removeEventListener("click", showOpenContentHandler);
          }),
          closeContentButtons.forEach(function (element) {
            element.removeEventListener("click", hideOpenContentHandler);
          });
      });
    var toggleMenuLvl1 = function () {
        mobileNav.classList.contains("menu-lvl1-open")
          ? closeMenuLvl1()
          : (openMenuLvl1(), myApp.headerMenu.loadOpenContent(mobileNav));
      },
      openMenuLvl1 = function () {
        mobileNav.classList.add("menu-lvl1-open"),
          body.classList.add("noscroll");
      },
      openMenuLvl2 = function (element) {
        mobileNav.classList.add("menu-lvl2-open"),
          menuLvl1Items.forEach(function (item) {
            item.classList.remove("submenu-active");
          }),
          element.classList.add("submenu-active");
      },
      closeMenuLvl1 = function () {
        mobileNav.classList.remove("menu-lvl1-open"),
          body.classList.remove("noscroll"),
          menuLvl1Items.forEach(function (element) {
            !(function (element) {
              mobileNav.classList.remove("menu-lvl2-open"),
                element.classList.remove("submenu-active");
            })(element);
          });
      },
      closeMenuLvl1IfUnfocused = function () {
        mobileNav.contains(document.activeElement) || closeMenuLvl1();
      };
    function closeMenuLvl1IfTouchedOutside(touchOrClickEvent) {
      mobileNav.contains(touchOrClickEvent.target) || closeMenuLvl1();
    }
    return pub;
  })()),
  ((myApp = myApp || {}).headerMenu = (function () {
    "use strict";
    var pub = {},
      timeout = !1;
    function checkWindowSize() {
      977 <= window.innerWidth
        ? (myApp.headerMenuMobile.deinit(), myApp.headerMenuDesktop.init())
        : (myApp.headerMenuDesktop.deinit(), myApp.headerMenuMobile.init());
    }
    return (
      checkWindowSize(),
      window.addEventListener("resize", function () {
        clearTimeout(timeout), (timeout = setTimeout(checkWindowSize, 250));
      }),
      (pub.loadOpenContent = function (element) {
        element
          .querySelectorAll(".main-menu-open-content-wrapper")
          .forEach(function (script) {
            script.getAttribute("data-content") &&
              ((script.innerHTML = script.getAttribute("data-content").trim()),
              script.setAttribute("data-content", ""),
              (script = script.querySelector("script")) &&
                Function(script.innerHTML)());
          });
      }),
      window.addEventListener("load", (event) => {
        setTimeout(function () {
          pub.loadOpenContent(document.querySelector(".menu.lvl1"));
        }, 3e3);
      }),
      pub
    );
  })());
var headerSearch = (function () {
  var navBar = $("#siteHeader nav"),
    searchArea = navBar.find(".header-search"),
    searchInput = searchArea.find("input[type=search]"),
    searchSuggestions = searchArea.find(".search-suggestions-wrapper"),
    searchButton = searchArea.find(".search-button");
  searchButton.click(function () {
    var nearbySearchInput, nearbySearchArea;
    (nearbySearchInput = this),
      (nearbySearchArea = $(nearbySearchInput).closest(".header-search")),
      (nearbySearchInput = nearbySearchArea.find("input[type=search]")),
      nearbySearchArea.hasClass("search-expanded")
        ? nearbySearchInput.val()
          ? nearbySearchArea.find("form").submit()
          : (closeSearch(), searchButton.blur())
        : openSearch(nearbySearchArea);
  });
  function closeSearchIfUnfocused() {
    searchArea[0].contains(document.activeElement) ||
      searchArea[1].contains(document.activeElement) ||
      closeSearch();
  }
  var openSearch = function (activeSearchArea) {
      navBar.addClass("search-expanded"),
        searchArea.addClass("search-expanded"),
        searchInput.prop("disabled", !1),
        $(activeSearchArea).find("input[type=search]").focus();
    },
    closeSearch = function () {
      navBar.removeClass("search-expanded"),
        searchArea.removeClass("search-expanded"),
        searchInput.val(""),
        searchSuggestions.find(".suggest-results").html(""),
        searchInput.prop("disabled", !0);
    };
  searchArea.on("focusout", function () {
    setTimeout(closeSearchIfUnfocused, 100);
  }),
    searchInput.on("keyup", function (evt) {
      var suggestionsURL,
        query = $(this).val();
      1 < query.length
        ? ((suggestionsURL = new URL(
            searchSuggestions.find(".suggest-results").data("url")
          )).searchParams.set("suggestQuery", query),
          searchSuggestions.load(suggestionsURL.href))
        : searchSuggestions.find(".suggest-results").html("");
    });
})();
!(function () {
  var tabs, activeTabs;
  function hideInactive() {
    $.each(
      $(".listing-detail-tab-button:not(.active)"),
      function (indexInArray, valueOfElement) {
        $("." + $(valueOfElement).data("tab")).hide();
      }
    );
  }
  $(".listing-detail-component") &&
    ((tabs = $(".listing-detail-tab-selection").find(
      ".listing-detail-tab-button"
    )),
    (activeTabs = $(".overview")),
    $(".listing-detail-tab-dropdown").hide(),
    $(".dropdown-arrow").click(function (e) {
      $(".listing-detail-tab-dropdown").show();
    }),
    activeTabs.addClass("active"),
    hideInactive(),
    $.each(tabs, function (indexInArray, valueOfElement) {
      $(valueOfElement).click(function (e) {
        var tabName;
        (tabName = $(valueOfElement)),
          activeTabs.removeClass("active"),
          (activeTabs = $("." + tabName.data("tab-name"))).addClass("active"),
          $(".listing-detail-tab-dropdown").hide(),
          hideInactive(),
          $("." + $(activeTabs).data("tab")).show();
      });
    }));
})(),
  $(function () {
    $("#main-content").click(function (button) {
      var url = ".listings-map-component .load-more-button";
      (button.target.matches(url) || button.target.matches(url + " *")) &&
        ((button = button.target.closest(url)),
        (url = $(button).data("url")),
        $(button).remove(),
        $.get(url, function (data) {
          $(".search-results").append(data),
            myApp.tripAdvisorWidget.init(),
            document.dispatchEvent(
              new CustomEvent("loadedMoreAttractions", {
                detail: $(data).data("listings"),
              })
            );
        }));
    });
  }),
  (function () {
    var numResults = $(".nearby-result-batch").first().data("totalresults");
    $(".nearby-result-batch").first().data("editmode") ||
      (numResults && 0 != numResults) ||
      $(".nearby-component").addClass("hidden"),
      $(".nearby-component").on("visitmt-toggle", function (e) {
        $(".nearby-component select.display-type-select")
          .val(e.originalEvent.detail.value)
          .change();
      }),
      $(".nearby-filter-option").click(function () {
        var element;
        (element = this),
          $(".nearby-filter .nearby-filter-option").removeClass("selected"),
          $(element).addClass("selected"),
          $(".nearby-component select.content-type-select")
            .val($(element).data("value"))
            .change();
      }),
      $(".nearby-inputs select").change(function () {
        nearbyWrapper = $(".nearby-results");
        var filter = $(".nearby-component .content-type-select").val(),
          displayType = $(".nearby-component .display-type-select").val(),
          dataUrl = $(".nearby-result-batch").first().data("url");
        (nearbyResultsUrl = new URL(dataUrl)),
          nearbyResultsUrl.searchParams.set("filter", filter),
          nearbyResultsUrl.searchParams.set("displaytype", displayType),
          nearbyWrapper.load(nearbyResultsUrl.href);
      });
  })(),
  Element.prototype.matches ||
    (Element.prototype.matches =
      Element.prototype.msMatchesSelector ||
      Element.prototype.webkitMatchesSelector),
  Element.prototype.closest ||
    (Element.prototype.closest = function (s) {
      var el = this;
      do {
        if (el.matches(s)) return el;
      } while (
        null !== (el = el.parentElement || el.parentNode) &&
        1 === el.nodeType
      );
      return null;
    }),
  $(".visitmt-read-more").each(function (index, buttons) {
    var text = $(buttons),
      buttons = $(
        '<div class="visitmt-read-more-buttons"><span class="visitmt-read-more-button">Read More</span><span class="visitmt-read-less-button">Read Less</span></div>'
      );
    function checkHeight() {
      var elementHeight = Math.ceil(text[0].getBoundingClientRect().height),
        scrollableHeight = text[0].scrollHeight;
      scrollableHeight < text.parent().height()
        ? text.addClass("text-fits-container")
        : text.removeClass("text-fits-container"),
        scrollableHeight <= elementHeight
          ? text.addClass("text-cant-expand")
          : text.removeClass("text-cant-expand");
    }
    text.addClass("compact"),
      text.after(buttons),
      checkHeight(),
      buttons.find(".visitmt-read-more-button").click(function () {
        text.removeClass("compact"), checkHeight();
      }),
      buttons.find(".visitmt-read-less-button").click(function () {
        var doc = $(document),
          distance_from_bottom = doc.height() - doc.scrollTop();
        text.addClass("compact"),
          checkHeight(),
          doc.scrollTop(doc.height() - distance_from_bottom);
      }),
      $(window).scroll(checkHeight),
      $(window).resize(checkHeight);
  }),
  $(document).ready(function () {
    var targets = $(".search-main .trigger-submit"),
      selectedFilter = $("#Filter").val();
    $(".search-filter-option").each(function (index, element) {
      $(element).data("value") == selectedFilter &&
        $(element).addClass("selected");
    }),
      $(".search-filter-option").click(function (value) {
        value = $(value.target).data("value");
        $("#Filter").val(value), $(".search-main form.visitmt-search").submit();
      }),
      targets.change(function (event, target) {
        $(".search-main form.visitmt-search").submit();
      });
  }),
  $(function () {
    $("#main-content").click(function (button) {
      var url = ".search-results .load-more-button";
      (button.target.matches(url) || button.target.matches(url + " *")) &&
        ((button = button.target.closest(url)),
        (url = $(button).data("url")),
        $(button).remove(),
        $.get(url, function (data) {
          $(".search-results").append(data),
            myApp.tripAdvisorWidget.init(),
            document.dispatchEvent(
              new CustomEvent("loadedMoreAttractions", {
                detail: $(data).data("listings"),
              })
            );
        }));
    });
  }),
  $(document).ready(function () {
    $("a").each(function () {
      $(this).attr("href") &&
        "visitmt.my.salesforce-sites.com" === new URL(this).hostname &&
        $(this).click(function (e) {
          e.preventDefault(),
            window.open($(this).attr("href"), "", "width=650,height=350");
        });
    });
  }),
  $(document).ready(function () {
    function fireEvent(control) {
      var e = control.hasClass("toggled")
          ? control.data("valuetwo")
          : control.data("valueone"),
        e = new CustomEvent("visitmt-toggle", {
          bubbles: !0,
          detail: { value: e },
        });
      control[0].dispatchEvent(e);
    }
    $(".visitmt-toggle-control-button").each(function (i, element) {
      var control = $(element).closest(".visitmt-toggle-control");
      $(element).click(function (e) {
        control.toggleClass("toggled"), fireEvent(control);
      }),
        control.hasClass("toggled") && fireEvent(control);
    });
  });
var myApp = myApp || {};
(myApp.tripAdvisorWidget = (function () {
  var pub = {
    init: function () {
      $(document).ready(function () {
        $(".trip-advisor-widget").each(function (index, request) {
          var tripadvisorURL,
            widget = $(request);
          widget.data("loaded") ||
            ((tripadvisorURL = widget.data("tripadvisor-url")),
            (request = new XMLHttpRequest()).open("GET", tripadvisorURL, !0),
            request.send(),
            (request.onload = function () {
              var data = JSON.parse(this.response);
              widget.find(".tripadvisor-link").attr({ href: data.web_url }),
                widget
                  .find(".tripadvisor-rating-image")
                  .attr({ src: data.rating_image_url }),
                widget
                  .find(".tripadvisor-number-reviews")
                  .html(data.num_reviews + " reviews");
            }),
            widget.data("loaded", !0));
        });
      });
    },
  };
  return pub.init(), pub;
})()),
  ((myApp = myApp || {}).visitmtCarousel = (function () {
    "use strict";
    var pub = {},
      sharedCarouselOptions = {
        loop: !1,
        nav: !0,
        navContainerClass: "carousel-nav-container",
        navClass: ["carousel-previous-button", "carousel-next-button"],
        navText: [
          '<svg class="arrow" viewBox="0 0 34 34"><polygon points="20,11 20,10 10,16 10,17 20,23 20,22 11,16.5" style="fill:currentColor"></polygon></svg>',
          '<svg class="arrow" viewBox="0 0 34 34"><polygon points="13,11 13,10 23,16 23,17 13,23 13,22 22,16.5" style="fill:currentColor"></polygon></svg>',
        ],
        mouseDrag: !1,
        touchDrag: !1,
        pullDrag: !1,
        dots: !1,
        freeDrag: !1,
        autoWidth: !1,
        center: !0,
        items: 1,
      },
      bodyOverflowInitial = document.body.style.overflow;
    function initializeCarousel() {
      var startItem,
        mainCarouselOptions,
        carousel = $(this);
      (carousel.playerItems = []),
        carousel.data("initialized") ||
          ((startItem = carousel.data("start-item") || 0),
          ((mainCarouselOptions = sharedCarouselOptions).startPosition =
            startItem),
          (mainCarouselOptions.margin = 6),
          (mainCarouselOptions.center = !0),
          (mainCarouselOptions.onChanged = function (event) {
            !(function (carousel) {
              $.each(carousel.playerItems, function (index, item) {
                item.playerInfo.playerState == YT.PlayerState.PLAYING &&
                  item.pauseVideo();
              });
            })(carousel);
          }),
          (mainCarouselOptions.onInitialized = function (event) {
            !(function (carousel) {
              var modalCarousel,
                modalCarouselOptions = carousel.next();
              modalCarouselOptions.hasClass("visitmt-modal-carousel") &&
                ((modalCarousel = modalCarouselOptions).appendTo("body"),
                ((modalCarouselOptions = sharedCarouselOptions).onInitialized =
                  function () {
                    !(function (carousel, modalCarousel) {
                      carousel
                        .find(".carousel-modal-enter-button")
                        .each(function () {
                          this.addEventListener("click", function (event) {
                            modalCarousel.trigger("to.owl.carousel", [
                              $(this).data("num"),
                              0,
                            ]),
                              (document.body.style.overflow = "hidden"),
                              modalCarousel.show();
                          });
                        });
                    })(carousel, modalCarousel),
                      (function (carousel, modalCarousel) {
                        modalCarousel
                          .find(".carousel-modal-exit-button")
                          .each(function () {
                            var modalExitButton = this;
                            modalExitButton.addEventListener(
                              "click",
                              function () {
                                carousel.trigger("to.owl.carousel", [
                                  $(this).data("num"),
                                  0,
                                ]),
                                  (document.body.style.overflow =
                                    bodyOverflowInitial);
                                $(modalExitButton).data("videoid");
                                $(modalCarousel).hide();
                              }
                            );
                          });
                      })(carousel, modalCarousel);
                  }),
                modalCarousel.owlCarousel(modalCarouselOptions));
            })(carousel),
              carousel
                .find(".carousel-previous-button")
                .attr("aria-label", "Previous Carousel Item"),
              carousel
                .find(".carousel-next-button")
                .attr("aria-label", "Next Carousel Item");
          }),
          carousel.owlCarousel(mainCarouselOptions),
          carousel.data("initialized", !0),
          window.YT.ready(function () {
            !(function (carousel) {
              carousel
                .find(".carousel-video")
                .each(function (indexInArray, player) {
                  $(player).attr("id", $(player).attr("id") + indexInArray);
                  player = new YT.Player($(player).attr("id"), {
                    videoId: $(player).data("videoid"),
                    playerVars: { rel: 0 },
                  });
                  carousel.playerItems.push(player);
                });
            })(carousel);
          }));
    }
    return (
      (pub.initialize = function () {
        $(".owl-carousel.visitmt-carousel").each(initializeCarousel);
      }),
      pub.initialize(),
      pub
    );
  })()),
  $(".visitmt-featured-content-carousel").each(function () {
    var carousel = $(this),
      carouselOptions = {
        loop: !1,
        nav: !0,
        navContainerClass: "carousel-nav-container",
        navClass: ["carousel-previous-button", "carousel-next-button"],
        navText: [
          '<svg class="arrow" viewBox="0 0 34 34"><polygon points="20,11 20,10 10,16 10,17 20,23 20,22 11,16.5" style="fill:currentColor"></polygon></svg>',
          '<svg class="arrow" viewBox="0 0 34 34"><polygon points="13,11 13,10 23,16 23,17 13,23 13,22 22,16.5" style="fill:currentColor"></polygon></svg>',
        ],
        mouseDrag: !1,
        touchDrag: !1,
        pullDrag: !1,
        dots: !1,
        freeDrag: !1,
        center: !1,
        margin: 40,
        items: 1,
      };
    function initCarousel() {
      (window.innerWidth ||
        document.documentElement.clientWidth ||
        document.body.clientWidth) < 768
        ? (carousel.css("width", "199px"),
          carousel.owlCarousel(carouselOptions))
        : (carousel.css("width", ""), carousel.trigger("destroy.owl.carousel"));
    }
    $(".derp").click(function () {
      carousel.css("width", "199px");
    }),
      (carouselOptions.onInitialized = function (event) {
        $(".carousel-previous-button").attr(
          "aria-label",
          "Previous Carousel Item"
        ),
          $(".carousel-next-button").attr("aria-label", "Next Carousel Item");
      }),
      initCarousel();
    var timeout = !1;
    window.addEventListener("resize", function () {
      clearTimeout(timeout), (timeout = setTimeout(initCarousel, 250));
    });
  }),
  window.mapsReady
    .then(function () {
      "use strict";
      const circleIconPath = "M2 20 a 18 18 0 1 0 36 0 a 18 18 0 1 0 -36 0";
      $(".map-component").each(function (index, mapLoadButton) {
        var map,
          mapComponent = $(mapLoadButton),
          mapCanvas = mapComponent.find(".map-canvas");
        if (0 != mapCanvas.length) {
          const componentOptions = mapCanvas.data("options") || {};
          var activeInfoboxIndex,
            markerCluster,
            attractions = [],
            copyPanel = mapComponent.find(".copy-panel"),
            path =
              "SQUARE" == componentOptions.icon
                ? "M4,0 36,0 36,32 4,32 Z M4,1 L36,1 M4,1 L36,1 M4,2 L36,2 M4,3 L36,3"
                : "ROAD" == componentOptions.icon
                ? "M 20 53, L 39 23, L 35 23, A 16 16 0 1 0 5 23, L  1 23, L 20 53"
                : (componentOptions.icon, circleIconPath),
            markers = [],
            icon = {
              path: path,
              anchor: new google.maps.Point(20, 53),
              strokeWeight: 1,
              strokeColor: "#4f5a3b",
              fillColor: "#FFFFFF",
              fillOpacity: 1,
              scale: 1,
              labelOrigin: new google.maps.Point(20, 18),
            },
            mapOptions = {
              mapTypeId: google.maps.MapTypeId.ROADMAP,
              scrollwheel: !1,
            };
          "STYLE_A" == componentOptions.style
            ? (mapOptions.mapId = "c674d0748c43024")
            : "STYLE_B" == componentOptions.style &&
              (mapOptions.styles = [
                {
                  featureType: "administrative.province",
                  elementType: "geometry.stroke",
                  stylers: [{ weight: "4" }],
                },
                {
                  featureType: "administrative",
                  elementType: "labels.text.fill",
                  stylers: [{ color: "#000000" }],
                },
              ]);
          var mapLoadButton = new google.maps.LatLng(44.428, -110.5885),
            mapLoadButton =
              (new google.maps.Marker({
                position: mapLoadButton,
                map: map,
                draggable: !1,
                icon: { path: google.maps.SymbolPath.CIRCLE, scale: 0 },
                label: {
                  text: "Yellowstone National Park",
                  color: "black",
                  fontSize: "14px",
                  fontWeight: "Bold",
                },
              }),
              new google.maps.LatLng(48.7596, -113.787)),
            infoBox =
              (new google.maps.Marker({
                position: mapLoadButton,
                map: map,
                draggable: !1,
                icon: { path: google.maps.SymbolPath.CIRCLE, scale: 0 },
                label: {
                  text: "Glacier National Park",
                  color: "black",
                  fontSize: "14px",
                  fontWeight: "Bold",
                },
              }),
              new InfoBox({
                pixelOffset: new google.maps.Size(-40, -31),
                maxWidth: 275,
                disableAutoPan: !1,
                zIndex: 10,
                boxClass: "visitmt-map-infobox",
                boxStyle: { background: "white" },
                closeBoxMargin: "0",
                closeBoxURL:
                  $("body").data("context-path") +
                  "/binaries/content/gallery/MTOT/icons/modal-close-button.png",
                infoBoxClearance: new google.maps.Size(1, 1),
                isHidden: !1,
                pane: "floatPane",
                enableEventPropagation: !1,
                alignBottom: !1,
              }));
          $("[data-select-visitmt-map-marker]").click(function () {
            selectMapMarkerForItem($(this).data("select-visitmt-map-marker"));
          }),
            $("[data-show-visitmt-map-marker]").click(function () {
              infoBox.close();
              var markersToShow = $(this).data("show-visitmt-map-marker");
              markers.forEach(function (marker) {
                marker.setVisible(!1);
              }),
                markersToShow.forEach(function (i) {
                  markers[i].setVisible(!0);
                }),
                initializeCluster(),
                setBoundsAroundMarkers();
            }),
            $("[data-set-map-header-text]").click(function () {
              mapComponent
                .find(".map-title")
                .text($(this).data("set-map-header-text"));
            }),
            $(".hide-map").click(function () {
              infoBox.close(),
                mapComponent.removeClass("map-is-shown"),
                $("body").removeClass("trip-map-is-shown");
            }),
            $("button.show-map").click(function () {
              mapComponent.addClass("map-is-shown"),
                $("body").addClass("trip-map-is-shown");
            }),
            mapComponent.on("visitmt-toggle", function (e) {
              mapComponent
                .find(".map-panel, .load-more-button.visitmt-button")
                .toggleClass("hide"),
                $(
                  ".search-container, .search-results-map-component"
                ).toggleClass("map-enabled"),
                updateMap();
            });
          mapLoadButton = mapComponent.find(".map-load-button");
          function initializeMap() {
            map = new google.maps.Map(mapCanvas[0], mapOptions);
            var attractionsData = mapCanvas.data("attractions");
            (attractionsData && 0 != attractionsData.length) ||
              (attractionsData = mapComponent
                .find(".result-batch")
                .data("listings")),
              attractions.push(...(attractionsData = attractionsData || [])),
              document.addEventListener(
                "loadedMoreAttractions",
                function (attractionsObject) {
                  attractionsObject = attractionsObject.detail;
                  attractions.push(...attractionsObject), updateMap();
                }
              ),
              google.maps.event.addListenerOnce(
                map,
                "tilesloaded",
                function () {
                  document.getElementsByTagName("iframe")[0].title =
                    "Google Maps";
                }
              ),
              updateMap();
          }
          function updateMap() {
            var markerPositionCounts;
            map.panBy(0, 0),
              (markers = []),
              attractions.forEach(function (attraction, i) {
                var marker = new google.maps.LatLng(
                    attraction.latitude,
                    attraction.longitude
                  ),
                  marker = new google.maps.Marker({
                    position: marker,
                    map: map,
                    draggable: !1,
                    icon: icon,
                    label: {
                      text: componentOptions.enumerateMarkers
                        ? String(i + 1)
                        : String(1),
                      color: "black",
                    },
                  });
                markers.push(marker),
                  attraction.scrollCopyTo
                    ? google.maps.event.addListener(
                        marker,
                        "click",
                        function () {
                          var elementId;
                          selectMapMarkerForItem(i),
                            (elementId = attraction.scrollCopyTo),
                            "auto" == copyPanel.css("overflow-y").toLowerCase()
                              ? copyPanel[0].scrollBy(
                                  0,
                                  $(elementId).position().top
                                )
                              : window.scrollBy(
                                  0,
                                  $(elementId)[0].getBoundingClientRect().top -
                                    $("#siteHeader > nav").height()
                                );
                        }
                      )
                    : google.maps.event.addListener(
                        marker,
                        "click",
                        function () {
                          selectMapMarkerForItem(i);
                        }
                      );
              }),
              setBoundsAroundMarkers(),
              initializeCluster(),
              (markerPositionCounts = []),
              markers.forEach(function (marker) {
                var matchingCount = markerPositionCounts.find(function (
                  markerPositionCount
                ) {
                  return (
                    markerPositionCount.position.lat == marker.position.lat() &&
                    markerPositionCount.position.lng == marker.position.lng()
                  );
                });
                matchingCount
                  ? (offsetMarker(marker, 15e-6 * matchingCount.count),
                    matchingCount.count++)
                  : markerPositionCounts.push({
                      position: marker.position,
                      count: 1,
                    });
              });
          }
          function setBoundsAroundMarkers() {
            var latitude,
              zoom,
              latlng,
              bounds = new google.maps.LatLngBounds(),
              markerCount = 0;
            markers.forEach(function (marker) {
              var lat = marker.getPosition().lat(),
                lng = marker.getPosition().lng();
              lat == lat &&
                0 != lat &&
                lng == lng &&
                0 != lng &&
                marker.getVisible() &&
                (markerCount++, bounds.extend(marker.getPosition()));
            }),
              bounds.isEmpty() &&
                ((latitude = mapCanvas.data("center-latitude")),
                (latlng = mapCanvas.data("center-longitude")),
                (zoom = mapCanvas.data("zoom")),
                latitude && latlng
                  ? ((latlng = new google.maps.LatLng(latitude, latlng)),
                    map.setCenter(latlng),
                    zoom && map.setZoom(zoom))
                  : (bounds.extend(new google.maps.LatLng(49, -104.0487)),
                    bounds.extend(new google.maps.LatLng(44.37, -116)))),
              1 === markerCount &&
                google.maps.event.addListenerOnce(
                  map,
                  "bounds_changed",
                  function () {
                    this.setZoom(14);
                  }
                ),
              map.fitBounds(bounds);
          }
          function initializeCluster() {
            componentOptions.clustering &&
              (markerCluster && markerCluster.clearMarkers(),
              (markerCluster = new MarkerClusterer(map, markers, {
                styles: [
                  {
                    textColor: "black",
                    width: 40,
                    height: 64,
                    url: "/binaries/content/gallery/MTOT/icons/mappin.svg",
                    anchor: [10, 0],
                  },
                ],
                maxZoom: 22,
              })),
              google.maps.event.addListener(
                markerCluster,
                "clusterclick",
                function (cluster) {}
              ));
          }
          function showMarker(i) {
            markers[i].setMap(map);
          }
          function selectMapMarkerForItem(i) {
            void 0 !== activeInfoboxIndex && showMarker(activeInfoboxIndex),
              (function (i) {
                markers[i].setMap(null);
              })((activeInfoboxIndex = i));
            var cityBlock = markers[i].label.text;
            markers.forEach(function (marker) {
              marker.setZIndex();
            }),
              markers[i].setZIndex(google.maps.Marker.MAX_ZINDEX + 1),
              infoBox.close();
            var attraction = attractions[i],
              infoboxContent = "";
            attraction.url &&
              (infoboxContent =
                '<a class="visitmt-button attraction-button" href="' +
                attraction.url +
                '">' +
                attraction.buttonText +
                '<svg class="arrow" viewBox="-400 0 500 100" preserveAspectRatio="xMaxYMid slice" > <rect x="-400" y="45" width="490" height="10" style="fill:currentColor" /> <polygon points="100,50 22,0 22,15 80,50 22,85 22,100" style="fill:currentColor" /></svg></a>');
            var svgContent = `<svg
                    class="map-icon" 
                    style="width:40px;height:53px;top: -23px;position: absolute;left:39px;transform:translateX(-50%)"
                    viewBox="0 0 40 53"
                 >
                     <path fill="white" stroke="#5A6547" stroke-width="1px" d="${path}" />
                     <text style="text-anchor: middle; dominant-baseline: ideographic; font-size:14px;" x="50%" y="50%">${cityBlock}</text>
                 </svg>`,
              siteTypeBlock =
                "null" == attraction.siteType
                  ? ""
                  : '<h5 class="attraction-type">' +
                    attraction.siteType +
                    "</h5>",
              cityBlock =
                "null" == attraction.city
                  ? ""
                  : '<h5 class="attraction-city">' + attraction.city + "</h5>",
              infoboxContent =
                '<div class="infobox">' +
                svgContent +
                '<div class="infobox-body"><h5 class="attraction-title">' +
                attraction.title +
                "</h5>" +
                siteTypeBlock +
                '<picture><source media="(max-width: 767px)" srcset="' +
                attraction.imageMobile +
                '"><img src="' +
                attraction.imageDesktop +
                '" class="attraction-image" alt="' +
                attraction.imageAltText +
                '" aria-label="' +
                attraction.imageAltText +
                '"></picture>' +
                cityBlock +
                infoboxContent +
                "</div></div>";
            infoBox.setContent(infoboxContent),
              infoBox.open(map, markers[i]),
              infoBox.addListener("closeclick", () => {
                showMarker(i);
              });
          }
          0 == mapLoadButton.length
            ? initializeMap()
            : mapLoadButton.click(initializeMap);
        }
      });
    })
    .catch(function () {
      console.log("maps libraries failed to load!");
    }),
  (function () {
    var videos = $(".visitmt-youtube-video");
    videos.length &&
      window.YT.ready(function () {
        videos.each(function (indexInArray, element) {
          player = new YT.Player($(element).attr("id"), {
            videoId: $(element).data("videoid"),
            playerVars: { rel: 0 },
            events: {},
          });
        });
      });
  })();
